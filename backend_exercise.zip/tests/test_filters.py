from pubmed_papers.filters import is_non_academic, extract_email

def test_is_non_academic_true():
    assert is_non_academic("XYZ Biotech Inc.") is True

def test_is_non_academic_false():
    assert is_non_academic("Department of Computer Science, Stanford University") is False

def test_extract_email_valid():
    email = extract_email("Contact us at research@xyzbio.com")
    assert email == "research@xyzbio.com"

def test_extract_email_none():
    email = extract_email("No email here")
    assert email is None
