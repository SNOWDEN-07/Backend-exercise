from pubmed_papers.fetcher import fetch_pubmed_data

def test_fetch_pubmed_data_returns_list(monkeypatch):
    def mock_fetch_pubmed_data(query, debug=False):
        return [{
            "PubmedID": "123456",
            "Title": "Sample Title",
            "Publication Date": "2022",
            "Non-academic Author(s)": "John Doe",
            "Company Affiliation(s)": "XYZ Biotech",
            "Corresponding Author Email": "john@xyzbio.com"
        }]

    monkeypatch.setattr("pubmed_papers.fetcher.fetch_pubmed_data", mock_fetch_pubmed_data)
    result = fetch_pubmed_data("cancer", debug=True)
    assert isinstance(result, list)
    assert result[0]["PubmedID"] == "123456"
