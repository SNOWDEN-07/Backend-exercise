# PubMed Paper Fetcher

A command-line tool to search PubMed for research papers, filter those with non-academic pharmaceutical/biotech affiliations, and export results to CSV.

## Features

- Supports full PubMed query syntax
- Detects non-academic authors using affiliation heuristics
- Export results to CSV or print to console
- Email extraction of corresponding author

## Usage

```bash
poetry install
poetry run get-papers-list "cancer immunotherapy" -f results.csv --debug
```

## CLI Options

- `-h`, `--help`: Show help
- `-d`, `--debug`: Enable debug mode
- `-f`, `--file`: Specify output CSV filename

## Tools Used

- [Biopython](https://biopython.org/) for PubMed access
- Python standard libraries (`argparse`, `csv`, `re`)

## Project Structure

- `cli.py`: Command-line entry point
- `pubmed_papers/`: Logic modules (`fetcher`, `filters`, `exporter`)
- `tests/`: Unit tests
