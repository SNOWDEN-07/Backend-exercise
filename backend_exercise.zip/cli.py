import argparse
from pubmed_papers.fetcher import fetch_pubmed_data
from pubmed_papers.exporter import export_results

def main():
    parser = argparse.ArgumentParser(description="Fetch PubMed papers with non-academic authors")
    parser.add_argument("query", type=str, help="Search query for PubMed")
    parser.add_argument("-f", "--file", type=str, help="Output CSV filename")
    parser.add_argument("-d", "--debug", action="store_true", help="Enable debug mode")
    
    args = parser.parse_args()
    
    if args.debug:
        print(f"Searching PubMed for query: {args.query}")

    results = fetch_pubmed_data(args.query, debug=args.debug)

    if args.file:
        export_results(results, args.file)
    else:
        for row in results:
            print(row)

if __name__ == "__main__":
    main()
