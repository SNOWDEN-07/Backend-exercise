import csv
from typing import List, Dict

def export_results(data: List[Dict[str, str]], filename: str):
    if not data:
        print("No data to export.")
        return

    keys = data[0].keys()
    with open(filename, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(data)
    print(f"Results exported to {filename}")
