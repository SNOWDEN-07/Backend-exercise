import re

def is_non_academic(affiliation: str) -> bool:
    keywords = ["Inc", "Ltd", "Corporation", "Pharma", "Biotech", "Therapeutics", "LLC", "GmbH"]
    return any(keyword.lower() in affiliation.lower() for keyword in keywords)

def extract_email(text: str) -> str | None:
    match = re.search(r'[\w\.-]+@[\w\.-]+\.\w+', text)
    return match.group(0) if match else None
