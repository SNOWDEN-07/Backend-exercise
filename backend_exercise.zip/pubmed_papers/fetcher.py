from Bio import Entrez
from pubmed_papers.filters import is_non_academic, extract_email

from typing import List, Dict

Entrez.email = "your-email@example.com"  # Replace with your email

def fetch_pubmed_data(query: str, debug: bool = False) -> List[Dict[str, str]]:
    handle = Entrez.esearch(db="pubmed", term=query, retmax=10)
    record = Entrez.read(handle)
    ids = record["IdList"]

    handle = Entrez.efetch(db="pubmed", id=",".join(ids), rettype="medline", retmode="text")
    text = handle.read()

    from io import StringIO
    from Bio import Medline
    records = list(Medline.parse(StringIO(text)))

    results = []
    for rec in records:
        title = rec.get("TI", "")
        pubdate = rec.get("DP", "")
        pmid = rec.get("PMID", "")
        authors = rec.get("FAU", [])
        affils = rec.get("AD", "").split(";") if "AD" in rec else []

        non_acad_authors = []
        companies = []
        email = extract_email(rec.get("AD", ""))

        for affil in affils:
            if is_non_academic(affil):
                companies.append(affil.strip())

        if companies:
            non_acad_authors = authors

        results.append({
            "PubmedID": pmid,
            "Title": title,
            "Publication Date": pubdate,
            "Non-academic Author(s)": "; ".join(non_acad_authors),
            "Company Affiliation(s)": "; ".join(companies),
            "Corresponding Author Email": email or "N/A"
        })

    return results
